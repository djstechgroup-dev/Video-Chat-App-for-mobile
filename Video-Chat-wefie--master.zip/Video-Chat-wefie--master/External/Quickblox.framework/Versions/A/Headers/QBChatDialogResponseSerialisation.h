//
//  QBChatOneDialogResponseSerialisation.h
//  Quickblox
//
//  Created by Anton Sokolchenko on 9/2/14.
//  Copyright (c) 2014 QuickBlox. All rights reserved.
//

#import "QBJSONResponseSerialiser.h"

@interface QBChatDialogResponseSerialisation : QBJSONResponseSerialiser

@end
