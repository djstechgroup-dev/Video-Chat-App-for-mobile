/*
 *  PushToken.h
 *  MessagesService
 *

 *  Copyright 2010 QuickBlox team. All rights reserved.
 *
 */

#import <Quickblox/QBMPushTokenQuery.h>
#import <Quickblox/QBMPushTokenCreateQuery.h>
#import <Quickblox/QBMPushTokenDeleteQuery.h>
