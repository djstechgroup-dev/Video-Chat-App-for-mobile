/*
 *  Tasks.h
 *  MessagesService
 *

 *  Copyright 2011 QuickBlox team. All rights reserved.
 *
 */

#import <Quickblox/QBMGetTokenPerformer.h>
#import <Quickblox/QBMRegisterSubscriptionTask.h>
#import <Quickblox/QBMSendPushTask.h>
#import <Quickblox/QBMUnregisterSubscriptionTask.h>
