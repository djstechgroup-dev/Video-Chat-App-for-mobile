//
//  Requests.h
//  AuthService
//
//  Created by Igor Khomenko on 3/13/12.
//  Copyright (c) 2012 QuickBlox. All rights reserved.
//

#import <Quickblox/QBAuthRequests.h>

