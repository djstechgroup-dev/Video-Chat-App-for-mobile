//
//  QBChatCreateDialogRequestSerialiser.h
//  Quickblox
//
//  Created by Anton Sokolchenko on 9/4/14.
//  Copyright (c) 2014 QuickBlox. All rights reserved.
//

#import "QBJSONRequestSerialiser.h"

@interface QBChatCreateDialogRequestSerialiser : QBJSONRequestSerialiser

@end
