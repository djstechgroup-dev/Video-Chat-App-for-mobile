//
//  QBMUnregisterSubscriptionTaskResult.h
//  Quickblox
//
//  Created by Ruslan on 9/4/12.
//  Copyright (c) 2012 QuickBlox. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TaskResult.h"

@interface QBMUnregisterSubscriptionTaskResult : TaskResult {
}

@end
