/*
 *  Answer.h
 *  AuthService
 *

 *  Copyright 2010 Mob1serv team. All rights reserved.
 *
 */

#import <Quickblox/QBAAuthAnswer.h>
#import <Quickblox/QBAAuthSessionCreationAnswer.h>
#import <Quickblox/QBAAuthSessionDestroyAnswer.h>
