//
//  Answers.h
//  Quickblox
//
//  Created by IgorKh on 8/14/12.
//  Copyright (c) 2012 QuickBlox. All rights reserved.
//

#import <Quickblox/QBCOCustomObjectAnswer.h>
#import <Quickblox/QBCOMultiDeleteAnswer.h>
#import <Quickblox/QBCOCustomObjectPagedAnswer.h>

#import <Quickblox/QBCOFileBinaryAnswer.h>

#import <Quickblox/QBCOPermissionsAnswer.h>