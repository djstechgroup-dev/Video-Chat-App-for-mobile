//
//  BinaryResult.h
//  BaseService
//
//

#import <Foundation/Foundation.h>
#import "QBResult.h"


@interface BinaryResult : QBResult{

}
@property (nonatomic,readonly) NSData* data;
@end
