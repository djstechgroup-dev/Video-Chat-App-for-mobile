/*
 *  Server.h
 *  BaseService
 *
 *
 */
#import <Quickblox/QBBaseModule.h>