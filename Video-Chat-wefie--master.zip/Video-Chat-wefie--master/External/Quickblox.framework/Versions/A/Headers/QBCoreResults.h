/*
 *  Results.h
 *  BaseService
 *
 *
 */

#import <Quickblox/QBCoreResultsCommon.h>