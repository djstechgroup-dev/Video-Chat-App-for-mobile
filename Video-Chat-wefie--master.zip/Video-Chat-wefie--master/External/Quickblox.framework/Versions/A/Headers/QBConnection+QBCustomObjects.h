//
// Created by Andrey Kozlov on 24/02/2014.
// Copyright (c) 2014 QuickBlox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "QBConnection.h"

@interface QBConnection (QBCustomObjects)

+ (QBConnection *)customObjectsConnection;

@end