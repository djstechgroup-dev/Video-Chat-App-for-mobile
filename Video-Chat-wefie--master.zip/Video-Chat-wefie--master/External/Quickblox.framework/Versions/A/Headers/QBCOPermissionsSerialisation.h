//
// Created by Andrey Kozlov on 08/03/2014.
// Copyright (c) 2014 QuickBlox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "QBJSONResponseSerialiser.h"

@interface QBCOPermissionsSerialisation : QBJSONResponseSerialiser

@end