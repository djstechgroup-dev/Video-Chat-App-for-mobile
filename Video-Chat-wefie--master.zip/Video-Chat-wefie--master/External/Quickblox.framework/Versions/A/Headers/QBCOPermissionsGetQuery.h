//
//  QBCOPermissionsGetQuery.h
//  Quickblox
//
//  Created by Igor Khomenko on 7/4/13.
//  Copyright (c) 2013 QuickBlox. All rights reserved.
//

#import "QBCOCustomObjectGetQuery.h"

@interface QBCOPermissionsGetQuery : QBCOCustomObjectGetQuery

@end
