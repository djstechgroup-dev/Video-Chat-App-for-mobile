//
//  QBAAuthQuery.h
//  AuthService
//
//  Created by Igor Khomenko on 2/4/12.
//  Copyright (c) 2012 QuickBlox. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QBAAuthQuery : QBQuery

@end
