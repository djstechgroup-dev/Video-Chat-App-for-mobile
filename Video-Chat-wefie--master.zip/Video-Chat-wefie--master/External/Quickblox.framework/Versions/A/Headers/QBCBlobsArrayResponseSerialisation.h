//
//  QBCBlobsArrayResponseSerialisation.h
//  Quickblox
//
//  Created by Andrey Moskvin on 6/6/14.
//  Copyright (c) 2014 QuickBlox. All rights reserved.
//

#import "QBJSONResponseSerialiser.h"

@interface QBCBlobsArrayResponseSerialisation : QBJSONResponseSerialiser

@end
