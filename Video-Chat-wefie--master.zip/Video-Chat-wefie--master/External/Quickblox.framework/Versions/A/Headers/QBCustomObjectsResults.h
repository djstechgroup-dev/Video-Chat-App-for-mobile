//
//  Results.h
//  Quickblox
//
//  Created by IgorKh on 8/14/12.
//  Copyright (c) 2012 QuickBlox. All rights reserved.
//

#import <Quickblox/QBCOCustomObjectResult.h>
#import <Quickblox/QBCOMultiDeleteResult.h>
#import <Quickblox/QBCOCustomObjectPagedResult.h>

#import <Quickblox/QBCOPermissionsResult.h>

#import <Quickblox/QBCOFileResult.h>