//
//  QBCBlobRequestSerialisation.h
//  Quickblox
//
//  Created by Andrey Moskvin on 6/5/14.
//  Copyright (c) 2014 QuickBlox. All rights reserved.
//

#import "QBJSONRequestSerialiser.h"

@interface QBCBlobRequestSerialisation : QBJSONRequestSerialiser

@end
