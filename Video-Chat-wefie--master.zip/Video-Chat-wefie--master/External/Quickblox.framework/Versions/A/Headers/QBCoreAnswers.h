/*
 *  Answers.h
 *  BaseService
 *
 *
 */

#import <Quickblox/QBCoreAnswersCommon.h>
#import <Quickblox/EntityAnswer.h>