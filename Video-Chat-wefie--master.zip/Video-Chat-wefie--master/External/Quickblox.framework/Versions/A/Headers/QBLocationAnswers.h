/*
 *  Answer.h
 *  LocationService
 *
 
 *  Copyright 2010 QuickBlox team. All rights reserved.
 *
 */

#import <Quickblox/QBLGeoDataAnswer.h>
#import <Quickblox/QBLGeoDataPagedAnswer.h>

#import <Quickblox/QBLPlaceAnswer.h>
#import <Quickblox/QBLPlacePagedAnswer.h>
