//
//  QBMPushTokenRequestSerialisation.h
//  Quickblox
//
//  Created by Andrey Kozlov on 28/05/2014.
//  Copyright (c) 2014 QuickBlox. All rights reserved.
//

#import "QBJSONRequestSerialiser.h"

@interface QBMPushTokenRequestSerialisation : QBJSONRequestSerialiser

@end
