/*
 *  TaskResults.h
 *  ContentService
 *
 *  Copyright 2010 QuickBlox team. All rights reserved.
 *
 */

#import <Quickblox/QBCFileUploadTaskResult.h>
#import <Quickblox/QBCFileDownloadTaskResult.h>

