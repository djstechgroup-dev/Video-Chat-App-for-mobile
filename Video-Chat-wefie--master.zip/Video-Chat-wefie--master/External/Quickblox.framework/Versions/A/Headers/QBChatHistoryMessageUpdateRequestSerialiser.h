//
//  QBChatHistoryMessageUpdateRequestSerialiser.h
//  Quickblox
//
//  Created by Anton Sokolchenko on 9/3/14.
//  Copyright (c) 2014 QuickBlox. All rights reserved.
//

#import "QBJSONRequestSerialiser.h"

@interface QBChatHistoryMessageUpdateRequestSerialiser : QBJSONRequestSerialiser

@end
