//
//  QBLGeoDataRequestSerialisation.h
//  Quickblox
//
//  Created by Andrey Kozlov on 27/05/2014.
//  Copyright (c) 2014 QuickBlox. All rights reserved.
//

#import "QBJSONRequestSerialiser.h"

@interface QBLGeoDataRequestSerialisation : QBJSONRequestSerialiser

@end
