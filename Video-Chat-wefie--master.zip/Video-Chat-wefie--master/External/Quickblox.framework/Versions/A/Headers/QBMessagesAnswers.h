/*
 *  Answers.h
 *  MessagesService
 *

 *  Copyright 2010 QuickBlox team. All rights reserved.
 *
 */

#import <Quickblox/QBMessagesPushTokenAnswers.h>
#import <Quickblox/QBMessagesSubscriptionAnswers.h>
#import <Quickblox/QBMessagesEventAnswers.h>
