//
//  QBCOFileSerialisator.h
//  Quickblox
//
//  Created by Andrey Moskvin on 8/7/14.
//  Copyright (c) 2014 QuickBlox. All rights reserved.
//

#import "QBJSONResponseSerialiser.h"

@interface QBCOFileUploadInfoSerialisator : QBJSONResponseSerialiser

@end
