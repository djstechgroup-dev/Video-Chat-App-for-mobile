//
//  QBCOFileDeleteQuery.h
//  Quickblox
//
//  Created by Igor Khomenko on 10/10/13.
//  Copyright (c) 2013 QuickBlox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "QBCOFileQuery.h"

@interface QBCOFileDeleteQuery : QBCOFileQuery{

}

@end
