/*
 *  Common.h
 *  BaseService
 *
 *
 */
#import <Quickblox/QBResult.h>
#import <Quickblox/TaskResult.h>
#import <Quickblox/PagedResult.h>
#import <Quickblox/BinaryResult.h>
