//
//  QBLPlacesQuery.h
//  LocationService
//

//  Copyright 2011 QuickBlox  team. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "QBQuery.h"

@class QBLPlaceAnswer;

@interface QBLPlacesQuery : QBQuery {

}

@end