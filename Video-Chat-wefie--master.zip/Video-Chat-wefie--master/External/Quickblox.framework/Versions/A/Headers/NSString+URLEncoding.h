//
// Created by Andrey Kozlov on 04/03/2014.
// Copyright (c) 2014 QuickBlox. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (URLEncoding)
@end