/*
 *  Defnitions.h
 *  MessagesService
 *

 *  Copyright 2011 QuickBlox team. All rights reserved.
 *
 */

#import <Quickblox/QBMessagesConsts.h>
#import <Quickblox/QBMessagesEnums.h>
