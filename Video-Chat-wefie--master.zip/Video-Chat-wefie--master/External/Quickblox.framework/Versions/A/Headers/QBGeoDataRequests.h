/*
 *  QBGeoDataRequests.h
 *  LocationService
 *
 
 *  Copyright 2011 Quickblox team. All rights reserved.
 *
 */

#import <Quickblox/QBLGeoDataGetRequest.h>
#import <Quickblox/QBLGeoDataDeleteRequest.h>
