//
//  QBLGeoDataSerialisation.h
//  Quickblox
//
//  Created by Andrey Moskvin on 12/22/13.
//  Copyright (c) 2013 QuickBlox. All rights reserved.
//

#import "QBJSONResponseSerialiser.h"

@interface QBLGeoDataSerialisation : QBJSONResponseSerialiser

@end
