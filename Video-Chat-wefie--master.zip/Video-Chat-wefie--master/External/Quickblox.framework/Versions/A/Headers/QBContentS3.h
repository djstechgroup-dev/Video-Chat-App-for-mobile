/*
 *  S3.h
 *  ContentService
 *
 *  Copyright 2010 QuickBlox team. All rights reserved.
 *
 */

#import <Quickblox/QBCS3Answer.h>
#import <Quickblox/QBCS3PostAnswer.h>

