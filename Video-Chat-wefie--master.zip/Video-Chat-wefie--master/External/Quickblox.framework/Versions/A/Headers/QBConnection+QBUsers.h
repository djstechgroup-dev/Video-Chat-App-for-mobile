//
//  QBConnection+Users.h
//  Quickblox
//
//  Created by Andrey Kozlov on 09/01/2014.
//  Copyright (c) 2014 QuickBlox. All rights reserved.
//

#import "QBConnection.h"

@interface QBConnection (QBUsers)

+ (QBConnection *)usersConnection;

@end
