//
//  Server.h
//  ContentService
//

//  Copyright 2010 QuickBlox team. All rights reserved.
//

#import <Quickblox/QBContent.h>
