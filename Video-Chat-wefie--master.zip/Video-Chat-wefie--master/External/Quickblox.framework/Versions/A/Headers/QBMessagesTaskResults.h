/*
 *  TaskResults.h
 *  MessagesService
 *

 *  Copyright 2011 QuickBlox team. All rights reserved.
 *
 */

#import <Quickblox/QBMGetTokenTaskResult.h>
#import <Quickblox/QBMRegisterSubscriptionTaskResult.h>
#import <Quickblox/QBMSendPushTaskResult.h>
#import <Quickblox/QBMUnregisterSubscriptionTaskResult.h>
