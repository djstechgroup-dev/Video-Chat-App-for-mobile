/*
 *  Rest.h
 *  BaseService
 *
 *
 */

#import <Quickblox/QBRestRequest.h>
#import <Quickblox/QBRestResponse.h>