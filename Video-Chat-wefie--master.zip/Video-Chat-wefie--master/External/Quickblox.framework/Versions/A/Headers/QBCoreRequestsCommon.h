/*
 *  Common.h
 *  BaseService
 *
 *
 */

#import <Quickblox/Request.h>
#import <Quickblox/PagedRequest.h>