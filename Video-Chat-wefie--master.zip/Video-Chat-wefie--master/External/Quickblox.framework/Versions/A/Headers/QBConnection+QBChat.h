//
//  QBConnection+QBChat.h
//  Quickblox
//
//  Created by Anton Sokolchenko on 9/4/14.
//  Copyright (c) 2014 QuickBlox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "QBConnection.h"

@interface QBConnection (QBChat)

+ (QBConnection *)chatConnection;

@end
