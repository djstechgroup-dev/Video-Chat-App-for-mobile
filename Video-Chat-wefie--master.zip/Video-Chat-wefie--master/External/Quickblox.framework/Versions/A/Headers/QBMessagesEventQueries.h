/*
 *  EventQueries.h
 *  MessagesService
 *

 *  Copyright 2011 QuickBlox team. All rights reserved.
 *
 */

#import <Quickblox/QBMEventQuery.h>
#import <Quickblox/QBMEventCreateQuery.h>
#import <Quickblox/QBMEventGetQuery.h>
#import <Quickblox/QBMEventUpdateQuery.h>
#import <Quickblox/QBMEventDeleteQuery.h>
