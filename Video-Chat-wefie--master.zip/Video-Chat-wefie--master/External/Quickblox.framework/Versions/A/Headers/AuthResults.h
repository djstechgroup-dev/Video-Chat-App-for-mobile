/*
 *  Results.h
 *  AuthService
 *

 *  Copyright 2010 Quickblox team. All rights reserved.
 *
 */

#import <Quickblox/QBAAuthResult.h>
#import <Quickblox/QBAAuthSessionCreationResult.h>