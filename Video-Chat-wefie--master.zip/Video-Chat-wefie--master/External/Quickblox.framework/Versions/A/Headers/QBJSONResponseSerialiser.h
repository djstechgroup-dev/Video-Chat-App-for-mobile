//
//  QBJSONResponseSerialiser.h
//  Quickblox
//
//  Created by Andrey Kozlov on 26/05/2014.
//  Copyright (c) 2014 QuickBlox. All rights reserved.
//

#import "QBHTTPResponseSerialiser.h"

@interface QBJSONResponseSerialiser : QBHTTPResponseSerialiser

@end
