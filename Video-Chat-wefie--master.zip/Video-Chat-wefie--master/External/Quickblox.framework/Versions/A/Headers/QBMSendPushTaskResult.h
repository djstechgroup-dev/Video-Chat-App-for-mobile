//
//  QBMSendPushTaskResult.h
//  MessagesService
//

//  Copyright 2011 QuickBlox team. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TaskResult.h"


@interface QBMSendPushTaskResult : TaskResult {

}

@end
