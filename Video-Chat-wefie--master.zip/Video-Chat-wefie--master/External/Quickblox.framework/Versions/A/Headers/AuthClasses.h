/*
 *  Classes.h
 *  AuthService
 *

 *  Copyright 2011 QuickBlox team. All rights reserved.
 *
 */

#import <Quickblox/AuthDefinitions.h>
#import <Quickblox/AuthBusiness.h>
#import <Quickblox/AuthNet.h>
