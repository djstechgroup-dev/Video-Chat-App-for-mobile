//
//  QBCBlobObjectAccessResponseSerialisation.h
//  Quickblox
//
//  Created by Andrey Moskvin on 6/10/14.
//  Copyright (c) 2014 QuickBlox. All rights reserved.
//

#import "QBJSONResponseSerialiser.h"

@interface QBCBlobObjectAccessResponseSerialisation : QBJSONResponseSerialiser

@end
