//
// Created by Andrey Kozlov on 01/12/2013.
// Copyright (c) 2013 QuickBlox. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "QBConnection.h"

@interface QBHTTPConnection : QBConnection

@end