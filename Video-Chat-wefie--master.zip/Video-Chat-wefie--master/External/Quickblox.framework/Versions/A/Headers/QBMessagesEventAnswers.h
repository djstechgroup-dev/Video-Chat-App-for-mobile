/*
 *  Answers.h
 *  MessagesService
 *

 *  Copyright 2011 QuickBlox team. All rights reserved.
 *
 */

#import <Quickblox/QBMEventAnswer.h>
#import <Quickblox/QBMEventPagedAnswer.h>
