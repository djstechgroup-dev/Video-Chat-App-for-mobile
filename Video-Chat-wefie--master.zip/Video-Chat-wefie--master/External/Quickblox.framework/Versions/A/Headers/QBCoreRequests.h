/*
 *  Requests.h
 *  BaseService
 *
 *
 */

#import <Quickblox/QBCoreRequestsCommon.h>