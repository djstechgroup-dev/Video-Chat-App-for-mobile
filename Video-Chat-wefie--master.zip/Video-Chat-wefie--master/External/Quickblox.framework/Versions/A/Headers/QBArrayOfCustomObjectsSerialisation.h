//
// Created by Andrey Kozlov on 10/03/2014.
// Copyright (c) 2014 QuickBlox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "QBJSONResponseSerialiser.h"

@interface QBArrayOfCustomObjectsSerialisation : QBJSONResponseSerialiser

@end