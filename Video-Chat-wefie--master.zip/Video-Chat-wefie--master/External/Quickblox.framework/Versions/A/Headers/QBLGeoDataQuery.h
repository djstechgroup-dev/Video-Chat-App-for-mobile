//
//  QBLGeoDataQuery.h
//  LocationService
//

//  Copyright 2011 QuickBlox  team. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "QBQuery.h"

@interface QBLGeoDataQuery : QBQuery {

}

@end