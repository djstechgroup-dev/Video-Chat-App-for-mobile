//
//  QBLGeoDataResponsePageSerialisation.h
//  Quickblox
//
//  Created by Andrey Moskvin on 4/28/14.
//  Copyright (c) 2014 QuickBlox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "QBJSONResponseSerialiser.h"

@interface QBGeneralResponsePageSerialisation : QBJSONResponseSerialiser

@end
