//
//  QBCOCountSerialiser.h
//  Quickblox
//
//  Created by Andrey Moskvin on 8/26/14.
//  Copyright (c) 2014 QuickBlox. All rights reserved.
//

#import "QBJSONResponseSerialiser.h"

@interface QBCOCountSerialiser : QBJSONResponseSerialiser

@end
