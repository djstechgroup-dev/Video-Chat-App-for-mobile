/*
 *  Subscription.h
 *  MessagesService
 *

 *  Copyright 2010 QuickBlox team. All rights reserved.
 *
 */

#import <Quickblox/QBMSubscriptionQuery.h>
#import <Quickblox/QBMSubscriptionCreateQuery.h>
#import <Quickblox/QBMSubscriptionDeleteQuery.h>
#import <Quickblox/QBMSubscriptionGetQuery.h>
