/*
 *  Tasks.h
 *  Core
 *
 *  Copyright 2010 QuickBlox team. All rights reserved.
 *
 */

#import <Quickblox/QBCFileDownloadTask.h>
#import <Quickblox/QBCFileUploadTask.h>
#import <Quickblox/QBCFileUpdateTask.h>


