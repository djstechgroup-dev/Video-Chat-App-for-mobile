//
//  QBJSONRequestSerialiser.h
//  Quickblox
//
//  Created by Andrey Kozlov on 24/05/2014.
//  Copyright (c) 2014 QuickBlox. All rights reserved.
//

#import "QBHTTPRequestSerialiser.h"

@interface QBJSONRequestSerialiser : QBHTTPRequestSerialiser

@end
