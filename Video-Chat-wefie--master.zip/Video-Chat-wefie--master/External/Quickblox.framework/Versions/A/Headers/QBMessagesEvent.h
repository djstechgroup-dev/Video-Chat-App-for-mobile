/*
 *  Event.h
 *  MessagesService
 *

 *  Copyright 2011 QuickBlox team. All rights reserved.
 *
 */

#import <Quickblox/QBMEventResult.h>
#import <Quickblox/QBMEventPagedResult.h>
