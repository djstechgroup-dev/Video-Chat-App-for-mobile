/*
 *  Queries.h
 *  BaseService
 *
 *
 */
#import <Quickblox/QBCoreQueriesCommon.h>
