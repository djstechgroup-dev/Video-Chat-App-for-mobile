/*
 *  Result.h
 *  LocationService
 *
 
 *  Copyright 2010 QuickBlox team. All rights reserved.
 *
 */

#import <Quickblox/QBGeoDataResults.h>
#import <Quickblox/QBPlaceResults.h>