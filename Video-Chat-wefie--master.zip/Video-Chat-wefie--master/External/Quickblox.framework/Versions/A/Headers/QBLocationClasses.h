//
//  Classes.h
//  LocationService
//
//  Created by Igor Khomenko on 3/13/12.
//  Copyright (c) 2012 QuickBlox. All rights reserved.
//

#import <CoreLocation/CoreLocation.h>
#import <Quickblox/QBLocationDefinitions.h>
#import <Quickblox/QBLocationBusiness.h>
#import <Quickblox/QBLocationNet.h>
