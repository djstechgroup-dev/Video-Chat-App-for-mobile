//
// Created by Andrey Kozlov on 15/12/2013.
// Copyright (c) 2013 QuickBlox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "QBJSONResponseSerialiser.h"

@interface QBASessionSerialisation : QBJSONResponseSerialiser

@end