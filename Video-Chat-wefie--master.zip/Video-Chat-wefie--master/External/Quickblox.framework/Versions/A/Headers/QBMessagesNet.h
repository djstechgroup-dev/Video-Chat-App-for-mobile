/*
 *  Net.h
 *  MessagesService
 *

 *  Copyright 2010 QuickBlox team. All rights reserved.
 *
 */
#import <Quickblox/QBMessagesAnswers.h>
#import <Quickblox/QBMessagesQueries.h>
#import <Quickblox/QBMessagesResults.h>
#import <Quickblox/QBMessagesTasks.h>
#import <Quickblox/QBMessagesServer.h>