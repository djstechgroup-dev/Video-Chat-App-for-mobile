/*
 *  Results.h
 *  MessagesService
 *

 *  Copyright 2010 QuickBlox team. All rights reserved.
 *
 */

#import <Quickblox/QBMessagesPushToken.h>
#import <Quickblox/QBMessagesSubscription.h>
#import <Quickblox/QBMessagesEvent.h>
#import <Quickblox/QBMessagesTaskResults.h>
