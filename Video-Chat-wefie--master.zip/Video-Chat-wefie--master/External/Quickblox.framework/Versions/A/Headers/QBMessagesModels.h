/*
 *  Models.h
 *  MessagesService
 *

 *  Copyright 2010 QuickBlox team. All rights reserved.
 *
 */

#import <Quickblox/QBMPushToken.h>
#import <Quickblox/QBMSubscription.h>
#import <Quickblox/QBMEvent.h>


#import <Quickblox/QBMPushMessageBase.h>
#import <Quickblox/QBMPushMessage.h>
#import <Quickblox/QBMApplePushEvent.h>
