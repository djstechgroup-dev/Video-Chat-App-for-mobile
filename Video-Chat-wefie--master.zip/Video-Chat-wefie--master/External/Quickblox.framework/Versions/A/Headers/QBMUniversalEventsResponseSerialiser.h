//
//  QBMCreateEventResponseSerialiser.h
//  Quickblox
//
//  Created by Andrey Moskvin on 8/20/14.
//  Copyright (c) 2014 QuickBlox. All rights reserved.
//

#import "QBJSONResponseSerialiser.h"

@interface QBMUniversalEventsResponseSerialiser : QBJSONResponseSerialiser

@end
