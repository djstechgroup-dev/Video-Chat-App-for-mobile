/*
 *  Common.h
 *  BaseService
 *
 *
 */

#import <Quickblox/QBQuery.h>
#import <Quickblox/PagedQuery.h>