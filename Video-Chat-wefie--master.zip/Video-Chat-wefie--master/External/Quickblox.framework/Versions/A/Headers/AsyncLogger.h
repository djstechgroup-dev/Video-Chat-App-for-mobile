//
//  AsyncLogger.h
//  BaseService
//
//

#import <Foundation/Foundation.h>


@interface AsyncLogger : NSObject {
}

+(void)LogF:(NSString *)string;

@end
