/*
 *  Queries.h
 *  AuthService
 *

 *  Copyright 2011 QuickBlox team. All rights reserved.
 *
 */

#import <Quickblox/QBAAuthQuery.h>
#import <Quickblox/QBASessionCreationQuery.h>
#import <Quickblox/QBASessionDestroyQuery.h>


